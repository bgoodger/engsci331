
/******************************************************************************************************

	This is a template main file for the ENGSCI331 Eigenvectors module.  It demonstrates some new C++ 
	syntax and functions, as described in the accompanying document ENGSCI331_Eigenstuff.pdf.  

	*** There are some examples of "bad" programming in here (bits missing etc) that you will need to 
	find and fix, though this file should compile without errors straight away. ***

	You should use this file to get you started on the assignment.  You're welcome to change whatever
	you'd like to as you go, this is only a starting point.
	
======================================================================================================*/

#define _CRT_SECURE_NO_DEPRECATE

#include <iostream>
#include <fstream>
#include <string>
#include <cmath>

// This is the header file for your functions.  Usual programming practise would be to use a *.cpp 
// file that has the same name (ie: myEigenFunctions.cpp) and include it as normal in your project.
// Inside this file you'll see some ideas for functions that you could use during this project.  I 
// suggest you plan out your code first to see what kind of functions you'll use repeatedly and then
// write them.  
//#include "myEigenFunctions.h"
using namespace std;

#define PI 3.14159265358979323846
#define eps 0.00000000000000000000001
double DotProduct(double *A, double *B, int n) ;
void power_method(double **A, double *y, int n, double &lamdba, double delta);
void eigen_all (double **A, double *y, int n, double &lambda, double delta);
double Norm(double *A, int n);
double** deflate (double **A, int n,  double *y, double lambda);
void eigen_shift (double **A, double *y, int n, double &lambda, double delta);


int main(void) 
{
	// ----------------------------------------------------------------------------------------------
	//
	// PART 1: Initialisation
	//
	// ----------------------------------------------------------------------------------------------
	
	// Defining local variables to be used:

	int n = 0,						// n is the dimensions of the matrix, will be square for the eigen problems
		option = 0;					// the option whether to read the matrix from a file or to construct from 
									// user-entered values of k and m
  
	double *M = NULL,
		   *K = NULL;

	double **A = NULL;

	double G = 7.929*pow(10.0,10); 	// Shear modulus
	double rho = 7751; 			// Density
	double D = 0.005; 			// Wire diameter
	double R = 0.0532;			// Mean coil radius 
	double Na = 10; 			// number of active coils
 
 	n =(int) Na;
	// Allocating memory for the 1D arrays - these are the number of masses, n, long:
	M = new double [n];
	K = new double [n];

	// Allocating memory for the 2D arrays - these have dimensions of n*n:
	A = new double* [n];
	for(int i = 0; i < n; i++) 
		A[i] = new double [n];

	cout << "making mk" <<"\n";

	for(int i = 0; i < n; i++)  {
		M[i] = PI*PI*D*D*rho*R/2;
		K[i] = (G*pow(D,4))/(64*pow(R,3));

	}

	K[0] = 2*K[0]; // Correct first value
 
 	cout << "making A" <<"\n";
	A[0][0] = ( -K[0] -K[1]) / M[0];

	A[n-1][n-1] = -K[n-1] / M[n-1];
	A[n-1][n-2] = K[n-1] / M[n-1];
	A[n-2][n-1] = K[n-1] / M[n-2];

	for(int i = 1; i < n-1; i++) {
		A[i][i] = (-K[i] -K[i+1]) / M[i];
		A[i][i-1] = K[i] / M[i];
		A[i-1][i] = K[i] / M[i-1];
	}

	for(int i = 0; i < n; i++)  {
		for(int j = 0;j < n; j++)  {
			A[i][j] = -1* A[i][j];
		//	cout << A[i][j] << " ";
		}
		cout << "\n";
	}

	// -----------------------------------------------------------------------------------------------
	//
	//	PART 3: Solving the eigen problem
	//
	// -----------------------------------------------------------------------------------------------
	
	cout << "making y" <<"\n";

	double* y = new double [n];
	for(int i = 0; i < n; i++) 
		y[i] = 0;

	y[0] = 1;

	double lambda = 0;

	double delta = 0.00000000001;
	cout << "\n" << "Shifting" << "\n";
	//eigen_shift (A, y, n, lambda, delta);

	cout << "\n\nAll" << "\n";
	//eigen_all (A, y, n, lambda, delta);

	for(int i = 1; i < 20; i+=2) {
		cout << (i*D*sqrt(G/(2*rho)))/(16*PI*R*R*Na) << "  ";
	}

	// -----------------------------------------------------------------------------------------------
	//
	//	PART 5: Housekeeping
	//
	// -----------------------------------------------------------------------------------------------

	for(int i = 0; i < n; i++) {
		delete [] A[i];
	}
	delete [] A;

	cout << "I'm finished!"<<endl;
}


void eigen_shift (double **A, double *y, int n, double &lambda, double delta) {

	double largeLambda; 

	double **B = new double* [n];
	for(int i = 0; i < n; i++) 
		B[i] = new double [n];

	power_method(A, y, n, lambda, delta);

	cout << "Largest lambda " << " : " << -1*lambda << "\n"; 
	cout << "Natural Frequency " << " : " << sqrt(lambda)/(2*PI) << "\n"; 
	cout << "y"  << ":\n";
	for(int i = 0; i < n; i++) {
		std::cout << y[i] << "  "; 
	}

	largeLambda = lambda;

	for(int i = 0; i < n; i++) {
		for(int j = 0; j < n; j++) {
			B[i][j] = A[i][j] -  ((i==j)? largeLambda : 0);
		}
	}

	cout << "\n";

	power_method(B, y, n, lambda, delta);

	std::cout << "\nsmallest lambda " << " : " << -1*(largeLambda - lambda) << "\n"; 
	cout << "Natural Frequency " << " : " << sqrt(largeLambda - lambda)/(2*PI)<< "\n"; 
	std::cout << "y"  << ":\n";
	for(int i = 0; i < n; i++) {
		std::cout << y[i] << "  "; 
	}
	cout << "\n";
}


void eigen_all (double **A, double *y, int n, double &lambda, double delta) {

	for(int j = 0; j < n; j++) {
		power_method(A, y, n, lambda, delta);
		std::cout << "y" << j+1  << ":\n";
		for(int i = 0; i < n; i++) {
			std::cout << y[i] << "  "; 
		}
		std::cout << "\n" << "lambda " << j+1 << " : " << -1*lambda << "\n"; 
		cout << "Natural Frequency " << " : " << sqrt(lambda)/(2*PI) << "\n\n"; 

		A = deflate(A,n,y,lambda);
	}

}

double** deflate (double **A, int n,  double *y, double lambda) {

	double **B = new double* [n];
	for(int i = 0; i < n; i++) 
		B[i] = new double [n];

	for(int i = 0; i < n; i++) {
		for(int j = 0; j < n; j++) {
			B[i][j] = A[i][j] - lambda*y[i]*y[j];
		}
	}

	return B; 

}

void power_method (double **A, double *y, int n, double &lambda, double delta) {

	// Calculates the largest eigen vector and value for a square matrix A
	// The initial y vector is modified in place to be the normalised eigen vector
	// delta is the user defined tolerance
	// A must be a square matrix of dimension n, and y must be n long 

	lambda = Norm(y ,n);
	double lambdaOld;
	double yNew[n];

	for(int i = 0; i < n; i++)
		y[i] = 1/sqrt(n);

	while (true) {

		// A * y 
		for(int i = 0; i < n; i++) {
			yNew[i] = 0;
			for(int j = 0; j < n; j++) {
				yNew[i] += A[i][j] * y[j];
			}
		}

		for(int i = 0; i < n; i++) {
			y[i] = yNew[i];
		}

		lambdaOld = lambda; 
		lambda = Norm(y ,n);

		// y = y / lambda
		for(int i = 0; i < n; i++) {
			y[i] = y[i] / lambda;
		}

		if ((abs(lambda - lambdaOld) / abs(lambda)) < delta)  {
			// We have converged!
			return;
		}
	}

	/*	for (int i = 0; i < n; i++) {
			if ((abs(y[i]) > eps) && (abs(yNew[i])>eps)) {
				if (y[i] + yNew[i] < y[i] + yNew[i]) {
					lambda = -1*lambda;
					break;
				}
			}
		} */
		


}

double Norm(double *A, int n) {

	// Returns the (pythagorean?) norm of a vector
	return  sqrt(DotProduct(A,A,n));

}

double DotProduct(double **A, double **B, int n, int m)
{
	//
	//	This is a function that takes two matrices A and B of identical dimensions (n*m) and 
	//  calculates and returns their dot product.
	//
	double dot = 0.0;

	for(int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++) {
			dot += A[i][j]*B[i][j];
		}
	}
	return dot;
}

double DotProduct(double *A, double *B, int n) 
{
	//
	//	This is a function that takes two vectors A and B of identical length (n) and 
	//  calculates and returns their dot product.
	//

	double dot = 0.0;

	for(int i = 0; i < n; i++) {
		dot += A[i]*B[i];
	}
	return dot;

}

void user_in(double *M, double *K, int n) {
			cout << "Please enter your masses: \n";
			for(int i = 0; i < n; i++) {
				cout<<"m"<< i <<": ";
				cin >> M[i];
				cout<<"\n";
			}

			cout << "Please enter your spring constants: \n";
			for(int i = 0; i < n; i++) {
				cout<<"k"<< i <<": ";
				cin >> K[i];
				cout<<"\n";
			}
}